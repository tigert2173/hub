const characterGrid = document.querySelector('.character-grid');

// Fetch characters for moderation
async function fetchCharacters() {
    try {
        const response = await fetch('http://localhost:3001/api/characters');
        if (response.ok) {
            const characters = await response.json();
            populateCharacterGrid(characters);
        } else {
            console.error('Failed to fetch characters.');
        }
    } catch (error) {
        console.error('Error fetching characters:', error);
    }
}

// Populate character grid for moderation
function populateCharacterGrid(characters) {
    characterGrid.innerHTML = ''; // Clear existing characters
    characters.forEach(character => {
        const card = document.createElement('div');
        card.classList.add('character-card');

        const header = document.createElement('div');
        header.classList.add('card-header');
        const title = document.createElement('h3');
        title.textContent = character.name;
        header.appendChild(title);

        const body = document.createElement('div');
        body.classList.add('card-body');
        const uploader = document.createElement('p');
        uploader.textContent = `Uploaded by: ${character.uploader}`;
        const status = document.createElement('p');
        status.textContent = `Status: ${character.status}`;
        const tags = document.createElement('p');
        tags.classList.add('tags');
        tags.textContent = `Tags: ${character.tags.join(', ')}`;

        const approveBtn = document.createElement('button');
        approveBtn.classList.add('approve-btn');
        approveBtn.textContent = 'Approve';
        approveBtn.addEventListener('click', () => approveCharacter(character.id));

        const rejectBtn = document.createElement('button');
        rejectBtn.classList.add('reject-btn');
        rejectBtn.textContent = 'Reject';
        rejectBtn.addEventListener('click', () => rejectCharacter(character.id));

        const deleteBtn = document.createElement('button');
        deleteBtn.classList.add('delete-btn');
        deleteBtn.textContent = 'Delete';
        deleteBtn.addEventListener('click', () => deleteCharacter(character.id));

        body.appendChild(uploader);
        body.appendChild(status);
        body.appendChild(tags);
        body.appendChild(approveBtn);
        body.appendChild(rejectBtn);
        body.appendChild(deleteBtn);
        card.appendChild(header);
        card.appendChild(body);

        characterGrid.appendChild(card);
    });
}

// Approve character
async function approveCharacter(id) {
    try {
        await fetch(`http://localhost:3001/api/characters/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'approved' }),
        });
        fetchCharacters(); // Refresh the character list
    } catch (error) {
        console.error('Error approving character:', error);
    }
}

// Reject character
async function rejectCharacter(id) {
    try {
        await fetch(`http://localhost:3001/api/characters/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: 'rejected' }),
        });
        fetchCharacters(); // Refresh the character list
    } catch (error) {
        console.error('Error rejecting character:', error);
    }
}

// Delete character
async function deleteCharacter(id) {
    if (confirm('Are you sure you want to delete this character?')) {
        try {
            await fetch(`http://localhost:3001/api/characters/${id}`, {
                method: 'DELETE',
            });
            fetchCharacters(); // Refresh the character list
        } catch (error) {
            console.error('Error deleting character:', error);
        }
    }
}

// Fetch characters on page load
document.addEventListener('DOMContentLoaded', fetchCharacters);

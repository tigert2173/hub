// hub-page.js

// Search Bar functionality
const searchBar = document.querySelector('.search-bar');
const characterGrid = document.querySelector('.character-grid');

// Fetch and display characters from the database
async function fetchCharacters() {
    try {
        const response = await fetch('http://localhost:3001/api/characters');
        if (response.ok) {
            const characters = await response.json();
            populateCharacterGrid(characters);
        } else {
            console.error('Failed to fetch characters.');
        }
    } catch (error) {
        console.error('Error fetching characters:', error);
    }
}

function populateCharacterGrid(characters) {
    characterGrid.innerHTML = ''; // Clear existing characters
    characters.forEach(character => {
        const card = document.createElement('div');
        card.classList.add('character-card');

        const header = document.createElement('div');
        header.classList.add('card-header');
        const title = document.createElement('h3');
        title.textContent = character.name;
        header.appendChild(title);

        const body = document.createElement('div');
        body.classList.add('card-body');

        const uploader = document.createElement('p');
        uploader.textContent = `Uploaded by: ${character.uploader}`;
        const status = document.createElement('p');
        status.textContent = `Status: ${character.status}`;
        const tags = document.createElement('p');
        tags.classList.add('tags');
        tags.textContent = `Tags: ${character.tags.join(', ')}`;

        const viewBtn = document.createElement('button');
        viewBtn.classList.add('view-btn');
        viewBtn.textContent = 'View Details';

        body.appendChild(uploader);
        body.appendChild(status);
        body.appendChild(tags);
        body.appendChild(viewBtn);
        card.appendChild(header);
        card.appendChild(body);

        characterGrid.appendChild(card);
    });
}

// Call fetchCharacters on page load
document.addEventListener('DOMContentLoaded', () => {
    fetchCharacters();
    fetchAIRecommendations(); // Ensure recommendations are fetched as well
});

// Filter functionality
const filterInputs = document.querySelectorAll('.sidebar input[type="checkbox"]');
filterInputs.forEach(input => {
    input.addEventListener('change', filterCharacters);
});

function filterCharacters() {
    const activeFilters = Array.from(filterInputs)
    .filter(input => input.checked)
    .map(input => input.id);

    const characterCards = characterGrid.querySelectorAll('.character-card');
    characterCards.forEach(card => {
        const tagsText = card.querySelector('.tags').textContent.toLowerCase();
        const matches = activeFilters.every(filter => tagsText.includes(filter));
        card.style.display = matches ? '' : 'none';
    });
}

// View Character functionality
characterGrid.addEventListener('click', (e) => {
    if (e.target.classList.contains('view-btn')) {
        const characterCard = e.target.closest('.character-card');
        const characterName = characterCard.querySelector('.card-header h3').textContent;
        // Implement modal or redirect to character detail page
        alert(`Viewing details for: ${characterName}`);
    }
});

// Upload Character functionality
document.querySelector('.upload-btn').addEventListener('click', () => {
    // Implement upload modal or redirect to upload page
    alert('Uploading a new character...');
});

// AI Recommendations functionality
const recommendationGrid = document.querySelector('.recommendation-grid');

async function fetchAIRecommendations() {
    try {
        const response = await fetch('/api/recommendations');
        if (response.ok) {
            const recommendations = await response.json();
            populateRecommendations(recommendations);
        } else {
            console.error('Failed to fetch recommendations.');
        }
    } catch (error) {
        console.error('Error fetching recommendations:', error);
    }
}

function populateRecommendations(recommendations) {
    recommendationGrid.innerHTML = ''; // Clear existing recommendations
    recommendations.forEach(rec => {
        const card = document.createElement('div');
        card.classList.add('recommendation-card');

        const header = document.createElement('div');
        header.classList.add('card-header');
        const title = document.createElement('h3');
        title.textContent = rec.name;
        header.appendChild(title);

        const body = document.createElement('div');
        body.classList.add('card-body');
        const desc = document.createElement('p');
        desc.textContent = rec.description;
        const chatBtn = document.createElement('button');
        chatBtn.classList.add('chat-btn');
        chatBtn.textContent = 'Chat Now';
        chatBtn.addEventListener('click', () => {
            // Implement chat functionality
            alert(`Starting chat with: ${rec.name}`);
        });

        body.appendChild(desc);
        body.appendChild(chatBtn);

        card.appendChild(header);
        card.appendChild(body);

        recommendationGrid.appendChild(card);
    });
}

// Fetch recommendations on page load
document.addEventListener('DOMContentLoaded', fetchAIRecommendations);
